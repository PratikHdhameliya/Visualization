The files in this directory contain the position and velocity of various bodies in the solar system between 1977-01-01 and 2024-12-31 in daily resolution. For the two space probes the data series starts on the day after their launch. The files are in standard CSV format. The columns in each file are:
date,X,Y,Z,VX,VY,VZ
The first is the date of the data in format YYYY-MM-DD, X,Y,Z are the position of the object in a 3d Cartesian coordinate system, centered on the barycenter of the solar system (which is approximately the position of the sun), and such that the disk of the solar system is approximately aligned with the XY plane. The unit of the axes is kilometer. VX,VY,VZ are the velocities of the object along the three axis in the unit kilometer per second.

The data was obtained from the JPL/NASA Horizons system at
https://ssd.jpl.nasa.gov/horizons/app.html#/
