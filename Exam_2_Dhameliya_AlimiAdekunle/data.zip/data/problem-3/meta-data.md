# traffic data
The files

agency.txt
routes.txt
shapes.txt
stops.txt
stop_times.txt
trips.txt

are in standard CSV format and they form a subset of a database of connected tables according to the General Transit Feed Specification (GTFS) specification, see here:
https://gtfs.org/documentation/schedule/reference/
The describe part of the public transport network in Schleswig-Holstein. Only the included tables are needed for the exam.
The original data is provided by the public transport network service of Schleswig-Holstein:
https://opendata.schleswig-holstein.de/dataset/fahrplandaten

# schematic map of germany
Some lines giving a schematic overview of germany are contained in the file
vg2500.npz
The line collections are just stored as unnamed arrrays of shape [2,N] and they can be imported and plotted via

tmp=np.load("vg2500.npz")
poslist=[tmp[k] for k in tmp.keys()]
del tmp

for pos in poslist:
    plt.plot(*pos,c="#808080")

You can use these lines to provide some orientation in a map.
The data is a slightly processed version of data made publicly available by the Bundesamt für Kartographie und Geodäsie (BKG):
https://gdz.bkg.bund.de/index.php/default/verwaltungsgebiete-1-2-500-000-stand-31-12-vg2500-12-31.html

# coordinate system convention
All spatial positions in this dataset have been converted to the EPSG:25832 (https://epsg.io/25832) coordinate reference system (CRS). This means you can treat all positions as coordinates in a simple 2d Cartesian coordinate system with meter as the unit of length. You do not have to worry about technical details involving the CRS. For compatibility with the General Transit Feed Specification (GTFS) data format the column names have not been changed and they still refer to latitude and longitude, even though the positions have been converted.

